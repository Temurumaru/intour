<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Intour/about</title>
    <?php echo $__env->make('blocks.head_imp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>

  <body>
    <div class="wrapper overflow-hidden">
      <header id="header" class="relative">
        <?php echo $__env->make('blocks.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div
          class="header__content bg-[url('./project/image/bg-about.png')]  md:mt-0 pt-32 pb-40 md:py-40 md:pb-50 text-white bg-no-repeat bg-cover"
        >
        <div class=" w-full h-full">
          <div class="container mx-auto">
            <h2 class="text-3xl md:text-6xl font-bold mb-3"><?php echo e(LN['about us']); ?></h2>
            <h3 class="text-lg md:text-2xl font-semibold">
              <a href="./"><?php echo e(LN['home']); ?></a> /
              <span class="text-logoColor">
                <a href="./about"><?php echo e(LN['about us']); ?></a></span
              >
            </h3>
          </div>
        </div>
        </div>
      </header>

      <section class="py-10 md:py-20">
        <div class="container mx-auto">
          <div class="grid md:grid-cols-2 grid-cols-1 gap-12">
            <div class="">
              <div data-aos="fade-up" class="py-4 md:py-5">
                <h5
                  class="text-base font-semibold uppercase text-logoColor md:text-lg"
                >
                  <?php echo e(LN['travel agency']); ?>

                </h5>
                <h1
                  class="text-2xl font-bold uppercase md:text-4xl text-bgColor"
                >
                  <?php echo e(LN['discover uzbekistan']); ?> <br class="md:block hidden"> <?php echo e(LN['with']); ?> 
                  <span class="text-logoColor"><?php echo e(LN['intour']); ?></span>
                </h1>
              </div>
              <p>
                <?php echo e(LN['our company has been providing its services in the field of tourism since 2016. despite its youth, our company has already accumulated experience and knowledge that help us provide high-level services to our customers.']); ?>

              </p>
              <div data-aos="fade-right" class="flex my-4 items-center">
                <i
                  class="ri-check-line w-5 h-5 text-white bg-logoColor mr-2.5 flex items-center justify-center rounded-full"
                ></i>
                <p><?php echo e(LN['5 years of experience']); ?></p>
              </div>
              <div data-aos="fade-right" class="flex my-4 items-center">
                <i
                  class="ri-check-line w-5 h-5 text-white bg-logoColor mr-2.5 flex items-center justify-center rounded-full"
                ></i>
                <p><?php echo e(LN['10+ tour destinations']); ?></p>
              </div>
              <div data-aos="fade-right" class="flex my-4 items-center">
                <i
                  class="ri-check-line w-5 h-5 text-white bg-logoColor mr-2.5 flex items-center justify-center rounded-full"
                ></i>
                <p><?php echo e(LN['1500+ happy customers']); ?></p>
              </div>
            </div>
            <div class="flex justify-center items-center">
              <div class="items-center__images">
                <div class="bg-main"></div>
                <img
                  class="absolute -top-5 -left-5"
                  src="./project/image/Circles.svg"
                  alt=""
                />
                <img
                  class="main"
                  src="./project/image/about us/Wallpaper.png"
                  alt=""
                />
                <img
                  class="toppe"
                  src="./project/image/about us/Toppe.svg"
                  alt=""
                />
              </div>
            </div>
          </div>
        </div>
        
        <div class="container mx-auto">
          <div data-aos="fade-up" class="py-8 md:py-10">
            <h5
              class="text-base font-semibold uppercase text-logoColor md:text-lg"
            >
              <?php echo e(LN['documents']); ?>

            </h5>
            <h1 class="text-2xl font-bold uppercase md:text-4xl text-bgColor">
              <?php echo e(LN['certificates']); ?>

            </h1>
          </div>
          <div class="grid grid-cols-3 md:gap-12 gap-6">
            <a class="gallery__card" onclick="card(this)" data-aos="fade-up" >
              <img class="w-full card__img object-contain  max-w-[440px] max-h-[480px]" src="./project/image/guvohnoma/Guvognoma.png" alt="" />
              <h2 class="lg:text-base mt-2 font-bold text-xs text-center">
                certificate
              </h2>
            </a>
            <a class="gallery__card"  onclick="card(this)" data-aos="fade-up">
              <img class="w-full  card__img object-contain  max-w-[440px] max-h-[480px]" src="./project/image/guvohnoma/Licence.png" alt="" />
              <h2 class="lg:text-base mt-2 font-bold text-xs text-center">
                licence
              </h2>
            </a>
            <a class="gallery__card text-center" onclick="card(this)" data-aos="fade-up">
              <img class="w-full object-contain   card__img max-w-[440px] max-h-[480px]" src="./project/image/guvohnoma/Photo Guide.png" alt="" />
              <h2 class="lg:text-base mt-2 font-bold text-xs ">
                Guvohnoma
              </h2>
            </a>
          </div>
        </div>
      </section>

      <?php echo $__env->make('blocks.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php echo $__env->make('blocks.foot_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH /home/temurumaru/Документы/projects/php/intour/resources/views/about.blade.php ENDPATH**/ ?>