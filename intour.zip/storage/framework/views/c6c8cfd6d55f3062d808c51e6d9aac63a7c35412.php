    <!--  js  -->
    <script>
      window.addEventListener("scroll", () => {
        let navbar = document.querySelector(".navbar");
        navbar.classList.toggle("navbar-fixed", window.scrollY > 80);
      });
    </script>

    <script src="./project/plugins/swiper/swipperJsBuld.js"></script>
    <script src="./project/plugins/flowbite/flowbite.js"></script>
    <script src="./project/js/swiper.js"></script>
    <script src="./project/plugins/aos/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="./project/js/script.js"></script>
    <!-- js --><?php /**PATH /home/temurumaru/Документы/projects/php/intour/resources/views/blocks/foot_js.blade.php ENDPATH**/ ?>