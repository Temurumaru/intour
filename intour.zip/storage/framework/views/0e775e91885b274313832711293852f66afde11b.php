<!-- Navbar Start -->
<nav style="height: 3.5rem;" class="navbar navbar-expand bg-secondary navbar-dark sticky-top px-4 py-0">
  <a href="<?php echo e(route('admin')); ?>" class="navbar-brand d-flex d-lg-none me-4">
    <h2 class="text-primary mb-0"><i class="fa fa-user-edit"></i></h2>
  </a>
  <a href="#" class="sidebar-toggler flex-shrink-0">
    <i class="fa fa-bars"></i>
  </a>
  <form class="d-none d-md-flex ms-4">
    
  </form>
  <div class="navbar-nav align-items-center ms-auto">
    
      
  </div>
</nav>
<?php if($errors->any() || session('success')): ?>
	<div class="err-claster shadow-all">
		<?php if(isset($errors)): ?>
			<?php if($errors->any()): ?>
				<div class="tst tst-err">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<p><?php echo e($error); ?></p>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			<?php endif; ?>
		<?php endif; ?>
		<?php if(session('warning')): ?>
			<div class="tst tst-warr"><?php echo e(session('warning')); ?></div>
		<?php endif; ?>
		
		<?php if(session('success')): ?>
			<div class="tst tst-succ"><?php echo e(session('success')); ?></div>
		<?php endif; ?>
	</div>
<?php endif; ?>
<!-- Navbar End --><?php /**PATH /home/intouru1/public_html/resources/views/blocks/adm_header.blade.php ENDPATH**/ ?>